//
//  HGCacheKit.swift
//  HiGame
//
//  Created by 极客 on 2017/6/5.
//  Copyright © 2017年 极客. All rights reserved.
//

import UIKit

class HGCacheKit: NSObject {

    /// 缓存接口对象
    /// object 要缓存的接口数据
    /// key 原始URL,函数内做MD5存储
    class func cache(_ object: AnyObject, forKey key:String) {
        DispatchQueue.global(qos: DispatchQoS.QoSClass.background).async {
            let path = HGJsonCacheDir + "/" + key.md5
            NSKeyedArchiver.archiveRootObject(object, toFile: path)
        }
    }
    
    /// 获取缓存数据
    /// key 原始URL,函数内做MD5存储
    class func getCacheObject(forKey key: String) -> AnyObject? {
        let path = HGJsonCacheDir + "/" + key.md5
        return NSKeyedUnarchiver.unarchiveObject(withFile: path) as AnyObject;
    }
    
    /// 清除单个缓存对象
    /// key: 原始URL,函数内做MD5
    class func removeCacheObject(forKey key: String) {
        let path = HGJsonCacheDir + "/" + key.md5
        do {
            try FileManager.default.removeItem(atPath: path)
        } catch {}
    }
    
    /// 清除所有缓存
    class func removeAllCache() {
        do {
            try FileManager.default.removeItem(atPath: HGJsonCacheDir)
            HGDirectoryManagerUtil.initLocalPath()
        } catch {}
    }
}

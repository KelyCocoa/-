//
//  HGDatabaseKit.swift
//  HiGame
//
//  Created by 极客 on 2017/6/11.
//  Copyright © 2017年 极客. All rights reserved.
//

import Foundation
import FMDB

class HGDatabaseKit: NSObject {
    
    /// 数据库全局单例
    public static let shared = HGDatabaseKit()
    
    var dbQueue: FMDatabaseQueue
    var currentDatabaseVersion: Int = 0
    override init() {
        dbQueue = FMDatabaseQueue(path: HGDatabaseKit.dbPath)
        super.init()
        if let configPath = Bundle.main.path(forResource: "HGDBUpGrade", ofType: "plist") {
            if let config = NSDictionary(contentsOfFile: configPath) as? Dictionary<String, AnyObject> {
                currentDatabaseVersion = config["HGDBUpGrade"] as! Int
            }
        }
        dbQueue.inDatabase { (db) in
            do {
                try db?.executeUpdate("pragma foreign_keys = on", values: nil)
            } catch {}
        }
    }
    
    /// +dbPath 返回数据库路径
    open class  var dbPath: String {
        return HGDatabaseDir + "/CZDatabase.sqlite3"
    }
    
    /// updateLocalDB 数据库升级
    open func updateLocalDB () {
        let versionLocal = UserDefaults.standard.integer(forKey: dbVersionLocal)
        if versionLocal < currentDatabaseVersion {
            applicationDidUpgrade(fromVersion: versionLocal, toVersion: currentDatabaseVersion)
            UserDefaults.saveInt(value: currentDatabaseVersion, key: dbVersionLocal)
        }
    }
    
    private func applicationDidUpgrade(fromVersion: Int, toVersion: Int) {
        if fromVersion == 0 || fromVersion < toVersion {
            upgradeDataBase(fromVersion: fromVersion, toVersion: currentDatabaseVersion)
        } else {
            upgradeDataBase(fromVersion: 0, toVersion: currentDatabaseVersion)
        }
    }
    
    private func upgradeDataBase(fromVersion: Int, toVersion: Int) {
        let configPath = Bundle.main.path(forResource: "HGDBUpGrade", ofType: "plist")
        guard let _configPath = configPath else {
            assert(true, "")
            return
        }
        let config = NSDictionary(contentsOfFile: _configPath) as? Dictionary<String, AnyObject>
        guard let _config = config else {
            return
        }
        upgradeDataBase(config: _config, fromVersion: fromVersion, toVersion: toVersion)
    }
    
    private func upgradeDataBase(config: Dictionary<String, AnyObject>, fromVersion: Int, toVersion: Int) {
        dbQueue.inDatabase { (db) in
            var successed = true
            let versions = config["upgradeVersions"] as? Array<String>
            guard let _versions = versions  else {
                return;
            }
            for version in _versions {
                let updgradeVersion = Int(version)
                guard let _updgradeVersion = updgradeVersion else {
                    assert(true, "")
                    break
                }
                if _updgradeVersion <= fromVersion {
                    continue
                } else if (_updgradeVersion > toVersion) {
                    break
                } else {
                    let updateSqlsDic = config["upgradeSQLs"] as? Dictionary<String, Array<String>>
                    let updateSqls = updateSqlsDic?[version]
                    if let updateSqls = updateSqls {
                        for sql in updateSqls {
                            successed = (db?.executeUpdate(sql: sql))!
                            if !successed {
                                HGLog(items: "Failed to upgrade  version \(fromVersion) to version \(toVersion), current sql is'\(sql)', reason is \(String(describing: db?.lastErrorMessage()))")
                            }
                        }
                    }
                }
            }
        }
    }
}

extension FMDatabase {
    func executeUpdate(sql: String?, _ args: CVarArg...) -> Bool {
        return executeUpdate(sql, withVAList: getVaList(args))
    }
    
    func executeQuery(sql: String, _ args: CVarArg...) -> FMResultSet? {
        return executeQuery(sql, withVAList: getVaList(args))
    }
}

//
//  HGUIDefine.swift
//  HiGame
//
//  Created by 极客 on 2017/6/17.
//  Copyright © 2017年 极客. All rights reserved.
//

import Foundation
import UIKit

let ScreenWidth = UIScreen.main.bounds.width
let ScreenHeight = UIScreen.main.bounds.height
let ScreenScale = UIScreen.main.scale
let statusBarHeight : CGFloat = 20
let FullScreen = UIScreen.main.bounds
let DeviceScale = UIScreen.main.scale


//Color

//
//  HGBaseControllerViewController.swift
//  HiGame
//
//  Created by 极客 on 2017/6/11.
//  Copyright © 2017年 极客. All rights reserved.
//

import UIKit
import RxCocoa

class HGBaseController: UIViewController,HGControllerProtocol {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        hg_addSubviews()
        hg_bindViewModel()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        hg_layoutNavigation()
        hg_getNewData()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func hg_addSubviews() {}
    func hg_bindViewModel() {}
    func hg_layoutNavigation() {}
    func hg_getNewData() {}
}

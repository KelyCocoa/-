//
//  HGControllerProtocol.swift
//  HiGame
//
//  Created by 极客 on 2017/6/11.
//  Copyright © 2017年 极客. All rights reserved.
//

import Foundation

@objc protocol HGControllerProtocol {
    /// 添加控件
    @objc optional func hg_addSubviews()
    ///  绑定controller 和 viewmodel
    @objc optional func hg_bindViewModel()
    /// 设置导航
    @objc optional func hg_layoutNavigation()
    /// 获取数据 （只在viewWillAppear:调用）
    @objc optional func hg_getNewData()
}

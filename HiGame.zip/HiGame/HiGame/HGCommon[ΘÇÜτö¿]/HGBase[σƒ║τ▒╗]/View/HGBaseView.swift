
//
//  HGBaseView.swift
//  HiGame
//
//  Created by 极客 on 2017/6/11.
//  Copyright © 2017年 极客. All rights reserved.
//

import UIKit

class HGBaseView: UIView {

    convenience init(viewModel: HGViewModelProtocol) {
        self.init(frame: CGRect())
        
    }
    
    convenience init() {
        self.init(frame: CGRect())
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        hg_bindViewModel()
        hg_addSubviews()
        hg_registerSelectorFromProtocols()
        hg_registerNotificationCenter()
        hg_registerGestureRecognizer()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    func hg_bindViewModel() {}
    func hg_addSubviews() {}
    func hg_registerSelectorFromProtocols() {}
    func hg_registerNotificationCenter() {}
    func hg_registerGestureRecognizer() {}
}

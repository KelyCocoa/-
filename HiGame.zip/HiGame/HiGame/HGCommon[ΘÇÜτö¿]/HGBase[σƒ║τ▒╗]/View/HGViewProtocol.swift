//
//  HGViewProtocol.swift
//  HiGame
//
//  Created by 极客 on 2017/6/11.
//  Copyright © 2017年 极客. All rights reserved.
//

import Foundation

@objc protocol HGViewProtocol {
    
    /// 绑定view 和 viewmodel
    @objc optional func hg_bindViewModel()
    /// 添加子视图
    @objc optional func hg_addSubviews()
    /// 订阅代理方法
    @objc optional func hg_registerSelectorFromProtocols();
    /// 注册通知中心
    @objc optional func hg_registerNotificationCenter();
    /// 注册手势
    @objc optional func hg_registerGestureRecognizer();
}

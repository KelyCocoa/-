//
//  HGLog.swift
//  HiGame
//
//  Created by 极客 on 2017/6/11.
//  Copyright © 2017年 极客. All rights reserved.
//

import UIKit

private let logFormat = DateFormatter()
public func HGLog<T>(items: T, fileName: String = #file, line: Int = #line, method: String = #function)
{
    #if DEBUG
        logFormat.dateFormat = "yyyy-MM-dd HH:mm:ss.SSS"
        print("\(logFormat.string(from: Date())) <\((fileName as NSString).lastPathComponent)>[\(line)]-\(method): \(items)")
    #endif
}

//
//  HGDirectoryManagerUtil.swift
//  HiGame
//
//  Created by 极客 on 2017/6/5.
//  Copyright © 2017年 极客. All rights reserved.
//

import UIKit

/// 沙河目录管理工具类


//Home目录
let HGHomeDir:String = NSHomeDirectory()
//Document目录
let HGDocumentDir:String = NSSearchPathForDirectoriesInDomains(FileManager.SearchPathDirectory.documentDirectory, FileManager.SearchPathDomainMask.userDomainMask, true).first!
//Library目录
let HGLibraryDir:String = NSSearchPathForDirectoriesInDomains(FileManager.SearchPathDirectory.libraryDirectory, FileManager.SearchPathDomainMask.userDomainMask, true).first!


//接口缓存目录
let HGJsonCacheDir:String = HGDocumentDir + "/JsonCacheDir"
//数据库目录
let HGDatabaseDir:String = HGDocumentDir + "/DataBaseDir"




class HGDirectoryManagerUtil: NSObject {

    /// 初始化本地目录
    /// 确保这些目录在使用时已经存在
    class func initLocalPath() {
        let fileManager = FileManager.default
        if fileManager.fileExists(atPath: HGJsonCacheDir) == false {
            do {
                try fileManager.createDirectory(atPath: HGJsonCacheDir, withIntermediateDirectories: true, attributes: nil)
            } catch {}
        }
        
        if fileManager.fileExists(atPath: HGDatabaseDir) {
            do {
                try fileManager.createDirectory(atPath: HGDatabaseDir, withIntermediateDirectories: true, attributes: nil)
            } catch {}
        }
        
        if fileManager.fileExists(atPath: HGDatabaseKit.dbPath) {
            do {
                try fileManager.createDirectory(atPath: HGDatabaseKit.dbPath, withIntermediateDirectories: true, attributes: nil)
            } catch {}
        }
    }
    
    
    /// 某个目录是否存在
    /// path 该目录所在的路径
    /// isCreateIfNotExists 如果该目录不存在是否创建该目录
    /// createDirectoryComplete 目录不存在 并选择创建目录后的创建结果 参数error可选型 nil表示创建成功
    /// 返回值 路径存在true 否则false
    class func directoryExists(atPath path: String, isCreateIfNotExists: Bool, createDirectoryComplete: ((Error?) -> Void)?) -> Bool {
        let fileManager = FileManager.default
        if fileManager.fileExists(atPath: path) == false {
            if isCreateIfNotExists == true {
                do {
                    try fileManager.createDirectory(atPath: path, withIntermediateDirectories: true, attributes: nil)
                    if let createDirectoryComplete = createDirectoryComplete {
                        createDirectoryComplete(nil)
                    }
                } catch let error {
                    if let createDirectoryComplete = createDirectoryComplete {
                        createDirectoryComplete(error)
                    }
                }
            }
            return false
        }
        return true
    }
    
    /// 移除某个目录下的所有文件
    /// inDirectory 目录路径
    /// complete 参数error 移除结果
    class func removeAllFiles(inDirectory: String, complete: ((Error?) -> Void)?) {
        DispatchQueue.global(qos: DispatchQoS.QoSClass.background).async {
            let fileManager = FileManager.default
            do {
                try fileManager.removeItem(atPath: inDirectory)
                DispatchQueue.main.async {
                    do {
                        try fileManager.createDirectory(atPath: inDirectory, withIntermediateDirectories: true, attributes: nil)
                    } catch {}
                    if let complete = complete {
                        complete(nil)
                    }
                }
            } catch let error {
                DispatchQueue.main.async {
                    if let complete = complete {
                        complete(error)
                    }
                }
            }
        }
    }
    
}

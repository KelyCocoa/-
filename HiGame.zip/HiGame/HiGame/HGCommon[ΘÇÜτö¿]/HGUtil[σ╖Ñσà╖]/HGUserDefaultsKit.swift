//
//  HGUserDefaultsKit.swift
//  HiGame
//
//  Created by 极客 on 2017/6/11.
//  Copyright © 2017年 极客. All rights reserved.
//

import UIKit

extension UserDefaults {
    
    class func saveObject(object:AnyObject, key:String) {
        self.standard.set(object, forKey: key)
        self.standard.synchronize()
    }
    
    class func getObject(key:String) -> AnyObject? {
        return self.standard.object(forKey: key) as AnyObject
    }
    
    class func saveObjects(objects:[AnyObject], keys:[String]) {
        for keyIndex in 0 ..< keys.count {
            self.saveObject(object: objects[keyIndex], key: keys[keyIndex])
        }
    }
    
    class func addObjectsAndKeysFromDictionary(keyValuePairs:[String:AnyObject]) {
        self.saveObjects(objects: Array(keyValuePairs.values), keys:Array(keyValuePairs.keys))
    }
    
    class func hasValueForKey(key:String) -> Bool {
        return Array(self.standard.dictionaryRepresentation().keys).index(of: key) != nil
    }
    
    class func saveInt(value:Int, key:String) {
        self.standard.set(value, forKey: key)
        self.standard.synchronize()
    }
    
    class func getInt(key:String) -> Int {
        return self.standard.object(forKey: key) as! Int
    }
    
    class func saveFloat(value:Float, key:String) {
        self.standard.set(value, forKey: key)
        self.standard.synchronize()
    }
    
    class func getFloat(key:String) -> Float {
        return self.standard.object(forKey: key) as! Float
    }
    
    class func saveDouble(value:Double, key:String) {
        self.standard.set(value, forKey: key)
        self.standard.synchronize()
    }
    
    class func getDouble(key:String) -> Double {
        return self.standard.object(forKey: key) as! Double
    }
    
    class func saveBool(value:Bool, key:String) {
        self.standard.set(value, forKey: key)
        self.standard.synchronize()
    }
    
    class func getBool(key:String) -> Bool {
        return self.standard.object(forKey: key) as! Bool
    }
    
    class func removeAllValues() {
        for key in Array(self.standard.dictionaryRepresentation().keys) {
            self.standard.removeObject(forKey: key)
        }
        self.standard.synchronize()
    }
    
    class func removeObjectForKey(key:String) {
        self.standard.removeObject(forKey: key)
        self.standard.synchronize()
    }
    
    class func resetValuesForKeys(key:String) {
        self.standard.removeObject(forKey: key)
        self.standard.synchronize()
    }
}
